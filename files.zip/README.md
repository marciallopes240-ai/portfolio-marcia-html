# Portfólio — Marcia Valéria da Silva Lopes

Portfólio profissional em HTML e CSS puros, sem dependências além das fontes do Google Fonts.

## Estrutura

```
index.html
css/style.css
img/foto.jpg
```

## Publicar no GitHub Pages

1. Envie todos os arquivos para um repositório (a pasta `css` e a pasta `img` devem ir junto).
2. No repositório, abra **Settings → Pages**.
3. Em **Build and deployment**, escolha **Deploy from a branch**, selecione a branch `main` e a pasta `/ (root)`, e salve.
4. Após alguns minutos o site fica em `https://SEU-USUARIO.github.io/NOME-DO-REPOSITORIO/`.
